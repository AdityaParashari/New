package org.cap.theatermgt.exception;

public class TheaterNotFoundException extends RuntimeException{
	 public TheaterNotFoundException(String msg){
	        super(msg);
}
}
	 