export class theater{

    theaterName:string;
    theaterCity:string;
    managerName:string;
    managerContact:string;
    constructor(theaterName:string,theaterCity:string,managerName:string,managerContact:string){
        this.theaterName=theaterName;
        this.theaterCity=theaterCity;
        this.managerName=managerName;
        this.managerContact=managerContact;

    }
}